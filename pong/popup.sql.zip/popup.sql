--
-- Database: `popup`
--

-- --------------------------------------------------------

--
-- Table structure for table `card`
--

CREATE TABLE `card` (
  `id` varchar(20) NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `card`
--

INSERT INTO `card` (`id`, `value`) VALUES
('exam50', 50),
('exam150', 150),
('exam100', 100),
('exam300', 300),
('exam500', 500),
('exam1000', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `cus`
--

CREATE TABLE `cus` (
  `cus_id` int(11) NOT NULL,
  `cus_name` varchar(255) NOT NULL,
  `wallet` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cus`
--

INSERT INTO `cus` (`cus_id`, `cus_name`, `wallet`) VALUES
(1, 'pong', 14900),
(8, 'max', 500),
(9, '????', 0),
(10, 'fdfdf', 0),
(11, 'dfdfsdgsdg', 0),
(12, 'Teest', 800),
(13, 'kick', 0);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `history_id` int(11) NOT NULL,
  `cus_id` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`history_id`, `cus_id`, `point`, `type`, `date`) VALUES
(1, 1, 500, 1, '0000-00-00 00:00:00'),
(2, 1, 50, 0, '0000-00-00 00:00:00'),
(3, 1, 50, 0, '0000-00-00 00:00:00'),
(4, 1, 5000, 1, '0000-00-00 00:00:00'),
(5, 1, 500, 1, '2016-01-27 13:11:38'),
(6, 8, 500, 1, '2016-01-27 13:52:52'),
(7, 12, 1000, 1, '2016-01-27 14:58:19'),
(8, 12, 50, 0, '2016-01-27 14:04:20'),
(9, 12, 50, 0, '2016-01-27 14:05:20'),
(10, 12, 50, 0, '2016-01-27 14:06:20'),
(11, 12, 50, 0, '2016-01-27 14:07:20');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `probability` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `name`, `probability`) VALUES
(1, 'Zombie Claw Cap', 0.3),
(2, 'Infest_1st SIG SAUER', 2),
(3, 'Nvidia Ultra Bomb!', 4),
(4, 'Flashbang', 5),
(5, 'Tt eSPORTS Medicine', 5),
(6, 'Medkit', 7),
(8, 'G 36 - Cmag', 8),
(9, '5.45 AK Drum', 8),
(10, 'STANAG 30', 8),
(7, 'Antibiotic', 7.7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cus`
--
ALTER TABLE `cus`
  ADD PRIMARY KEY (`cus_id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`history_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cus`
--
ALTER TABLE `cus`
  MODIFY `cus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
